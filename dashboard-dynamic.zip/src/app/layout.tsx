import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: '每日收盘报告',
  description: '个人投资复盘看板',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="zh-CN">
      <body className="bg-gray-900 text-white min-h-screen">
        {children}
      </body>
    </html>
  )
}
